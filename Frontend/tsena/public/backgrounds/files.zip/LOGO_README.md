# 🎨 FanJava Logos - Guide d'Utilisation

## 📦 Fichiers Disponibles

### 1. **fanjava_icon.svg** (200x200px)
**Usage** : Icône seule avec animation
- Applications mobiles
- Avatars de profil
- Icônes de navigation
- Taille : ~2 KB
- Animations : Pulse au centre, nodes animés

### 2. **fanjava_icon_minimal.svg** (100x100px)
**Usage** : Icône simplifiée sans animation
- Performance optimale
- Icônes statiques
- Boutons, badges
- Taille : ~1.5 KB

### 3. **fanjava_logo_complete.svg** (500x150px)
**Usage** : Logo horizontal complet
- Header de site web
- Signatures d'email
- Documents officiels
- Bannières
- Taille : ~3 KB
- **Inclut** : Icon + "FanJava" + badge ".mg" + tagline

### 4. **fanjava_logo_square.svg** (400x400px)
**Usage** : Logo carré pour réseaux sociaux
- Photo de profil Facebook/Twitter/LinkedIn
- Stories Instagram
- Vignettes YouTube
- Taille : ~3 KB
- **Format** : Icon en haut, texte centré en dessous

### 5. **fanjava_logo_dark.svg** (500x150px)
**Usage** : Version pour fonds sombres
- Mode dark
- Présentations
- Vidéos
- Taille : ~3 KB
- **Couleurs** : Blanc/bleu clair

### 6. **favicon.svg** (32x32px)
**Usage** : Icône de navigateur
- Tab browser (favicon)
- Bookmarks
- PWA icon
- Taille : ~0.8 KB
- **Ultra-simplifié** pour petites tailles

---

## 🎨 Design Elements

### Hexagone
- Représente la technologie, la structure
- Gradient bleu (#3b82f6 → #1e40af)
- Bordure #1e3a8a

### Circuit Pattern
- 3 lignes horizontales + 3 lignes verticales
- Symbolise la connexion, le réseau
- Gradient #60a5fa → #3b82f6

### Nodes (Points de connexion)
- 9 cercles blancs aux intersections
- Node central animé (pulse)
- Représente les connexions du marketplace

### Badge ".mg"
- Identifie clairement Madagascar
- Fond bleu translucide
- Bordure arrondie (pill shape)

---

## 💻 Intégration dans le Code

### React/JSX
```jsx
// Header
import Logo from '@/assets/fanjava_logo_complete.svg';

<img src={Logo} alt="FanJava" className="h-12" />
```

### HTML
```html
<!-- Favicon -->
<link rel="icon" type="image/svg+xml" href="/favicon.svg">

<!-- Logo header -->
<img src="/logos/fanjava_logo_complete.svg" alt="FanJava" height="48">
```

### CSS Background
```css
.logo-container {
  background-image: url('/logos/fanjava_icon.svg');
  background-size: contain;
  background-repeat: no-repeat;
}
```

### Inline SVG (pour contrôle CSS)
```jsx
<svg className="w-8 h-8 text-blue-600">
  <use href="/logos/fanjava_icon.svg#icon" />
</svg>
```

---

## 📐 Dimensions Recommandées

| Usage | Fichier | Dimensions |
|-------|---------|------------|
| Favicon | `favicon.svg` | 32x32px |
| App Icon iOS | `fanjava_icon_minimal.svg` | 180x180px |
| App Icon Android | `fanjava_icon_minimal.svg` | 192x192px |
| Header Desktop | `fanjava_logo_complete.svg` | 200x60px |
| Header Mobile | `fanjava_icon.svg` | 40x40px |
| Footer | `fanjava_logo_dark.svg` | 180x54px |
| Social Media | `fanjava_logo_square.svg` | 400x400px |
| Email Signature | `fanjava_logo_complete.svg` | 300x90px |

---

## 🎯 Exemples d'Utilisation

### 1. Header Navigation
```jsx
<header className="bg-white shadow">
  <div className="max-w-7xl mx-auto px-4">
    <Link to="/" className="flex items-center">
      <img 
        src="/logos/fanjava_logo_complete.svg" 
        alt="FanJava.mg" 
        className="h-12 w-auto"
      />
    </Link>
  </div>
</header>
```

### 2. Footer (Dark Mode)
```jsx
<footer className="bg-gray-900">
  <div className="max-w-7xl mx-auto px-4 py-8">
    <img 
      src="/logos/fanjava_logo_dark.svg" 
      alt="FanJava" 
      className="h-10 mb-4"
    />
  </div>
</footer>
```

### 3. Loading Screen
```jsx
<div className="flex items-center justify-center min-h-screen">
  <img 
    src="/logos/fanjava_icon.svg" 
    alt="Loading..." 
    className="w-24 h-24 animate-pulse"
  />
</div>
```

### 4. Favicon Multiple Formats
```html
<!-- Dans <head> -->
<link rel="icon" type="image/svg+xml" href="/favicon.svg">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
<link rel="manifest" href="/site.webmanifest">
```

---

## 🎨 Variantes de Couleurs

### Version Standard (Fonds Clairs)
- Hexagone : Gradient bleu (#3b82f6 → #1e40af)
- Circuit : Gradient bleu clair (#60a5fa → #3b82f6)
- Texte : Gradient bleu foncé (#1e3a8a → #3b82f6)
- Nodes : Blanc (#ffffff)

### Version Dark (Fonds Sombres)
- Hexagone : Gradient bleu clair (#60a5fa → #3b82f6)
- Circuit : Gradient bleu très clair (#93c5fd → #60a5fa)
- Texte : Gradient blanc (#ffffff → #dbeafe)
- Nodes : Bleu foncé (#1e3a8a)

---

## ⚡ Performance

- **Taille totale** : ~12 KB pour tous les fichiers
- **Format** : SVG vectoriel (scalable sans perte)
- **Animations** : CSS natives (pas de JavaScript)
- **Compatibilité** : Tous navigateurs modernes
- **Optimisation** : Pas de dépendances externes

---

## 🔄 Animations Incluses

### fanjava_icon.svg
```xml
<!-- Node central pulse -->
<animate attributeName="r" values="5;6;5" dur="2s" repeatCount="indefinite"/>

<!-- Highlight ring -->
<animate attributeName="r" values="8;12;8" dur="3s" repeatCount="indefinite"/>
<animate attributeName="opacity" values="0.4;0.8;0.4" dur="3s" repeatCount="indefinite"/>
```

**Désactiver les animations** (pour emails) :
```css
@media (prefers-reduced-motion: reduce) {
  svg * {
    animation: none !important;
  }
}
```

---

## 📱 Export vers autres formats

### Convertir SVG → PNG (si nécessaire)
```bash
# Avec Inkscape
inkscape fanjava_icon.svg --export-png=fanjava_icon.png --export-width=512

# Avec ImageMagick
convert -background none fanjava_icon.svg -resize 512x512 fanjava_icon.png
```

### Générer favicon.ico
```bash
# Créer plusieurs tailles puis les combiner
convert favicon.svg -resize 16x16 favicon-16.png
convert favicon.svg -resize 32x32 favicon-32.png
convert favicon-16.png favicon-32.png favicon.ico
```

---

## 🎯 Brand Guidelines

### ✅ À FAIRE
- Utiliser les fichiers SVG fournis
- Respecter les proportions
- Garder un espace minimum autour du logo (padding)
- Utiliser la version dark sur fonds sombres

### ❌ À NE PAS FAIRE
- Ne pas déformer le logo
- Ne pas changer les couleurs du gradient
- Ne pas ajouter d'ombre portée excessive
- Ne pas utiliser l'icône sans le texte si contexte peu clair
- Ne pas pixeliser (toujours utiliser SVG quand possible)

---

## 📦 Structure des Dossiers Recommandée

```
public/
  └── logos/
      ├── fanjava_icon.svg
      ├── fanjava_icon_minimal.svg
      ├── fanjava_logo_complete.svg
      ├── fanjava_logo_square.svg
      ├── fanjava_logo_dark.svg
      └── favicon.svg
      
  └── favicon.svg (à la racine pour le browser)
```

---

## 🚀 Quick Start

1. **Copier les fichiers** dans `/public/logos/`
2. **Ajouter le favicon** à `/public/favicon.svg`
3. **Importer dans Header** :
   ```jsx
   <img src="/logos/fanjava_logo_complete.svg" alt="FanJava" />
   ```
4. **Profit!** ✨

---

## 📞 Support

Pour toute question sur les logos ou demandes de variantes personnalisées, contactez l'équipe design.

**Dernière mise à jour** : Décembre 2024
**Version** : 1.0
**Licence** : Usage exclusif FanJava.mg
